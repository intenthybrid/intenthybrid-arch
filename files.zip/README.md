# Intent Hybrid

> *See the herd before it stampedes.*

![status](https://img.shields.io/badge/status-prototype-orange)
![license](https://img.shields.io/badge/license-MIT-3a6a5f)
![built with](https://img.shields.io/badge/built%20with-HTML%2FCSS%2FJS-informational)

**Intent Hybrid** (`intenthybrid AI`) is an autonomous AI agent that watches the *collective* behavior of DeFi trading bots to detect **algorithmic resonance** :: the moment when many independent strategies quietly synchronize and line up the same exit. When that crowding tips into a liquidation cascade, Intent Hybrid sees it forming and moves you out of the way first.

Most risk tools watch *price*. By the time price moves, the cascade has already happened. Intent Hybrid watches *the crowd* :: the leading indicator.

---

## The problem

DeFi did not get safer as it got more automated; it got more **correlated**. Thousands of bots run similar playbooks: the same momentum signals, the same liquidation thresholds, the same risk-off reflex. Each one is individually rational and collectively fragile. When they move together, price gaps, liquidations trigger more liquidations, and a cascade can clear the book in seconds.

- Roughly **$3.1B** was lost to DeFi exploits and cascades across 2024 and 2025.
- Herding among automated traders is well documented in academic literature (for example, CSAD-based dispersion studies), yet no live product turns it into an early warning for everyday users.

## How it works

Intent Hybrid scores **resonance**: how tightly the active agent population is converging on the same position and the same exit. The pipeline has six layers.

1. **Ingestion** :: streams low-latency preconfirmations from a high-performance L2, giving a head start of roughly a couple hundred milliseconds over confirmed blocks.
2. **Agent detection** :: clusters on-chain flow into behavioral cohorts (who is trading like whom).
3. **Resonance engine** :: collapses crowding into a single **Resonance Index** from 0 to 100.
4. **Decision AI** :: an LLM is woken only when the index crosses a threshold, so it reasons about real risk instead of noise.
5. **Execution** :: optional and fully scoped. Session keys with hard limits, routed through a private mempool. No custody, no blanket approvals.
6. **Delivery** :: pushes alerts and the live index over an API and a WebSocket feed.

## Products

| Surface | What it is | Status |
|---|---|---|
| **Resonance Index API** | A real-time B2B feed of the crowding index and agent-cohort signals. The core moat. | Core |
| **Guardian (dApp)** | A read-only dashboard: connect a wallet, see your exposure and live resonance, and get alerted before a cascade. No custody. | Live (prototype) |
| **Active Protection + Vault** | Opt-in automated defense that de-risks on your behalf using scoped session keys. | Phase 2 |

## Technology

### Today

- **Frontend** :: single-file, dependency-light HTML / CSS / JS (a marketing site and the Guardian dApp), JetBrains Mono type, HUD-style visuals.
- **Auth** :: wallet via EIP-1193, plus Google, X, and email login through Supabase.
- **Realtime** :: a low-latency preconfirmation stream feeding WebSocket delivery.
- **Decision layer** :: a threshold-gated, general-purpose LLM that is woken only on real risk, backed by transparent deterministic heuristics (cohort clustering and CSAD-style dispersion) as a fallback.

### Where the AI is headed: a model of our own

General-purpose models are where we start, not where we stop. Detecting resonance is a narrow and demanding problem, and our ambition is to build **a purpose-built model of our own** that does it natively instead of borrowing a chat model's judgment.

That dedicated AI is designed to:

- learn directly from the **behavioral fingerprints** of agent cohorts and from a growing library of labeled historical cascades;
- take coordinated bot activity as its native input, the language of crowding, order flow, and synchronized exits, rather than text;
- output a calibrated probability and a likely **timeline** for a cascade, not just a single score;
- improve continuously, learning from every cascade the network sees.

The goal is to move from *an LLM reasoning over signals* to *a model that perceives crowding directly*: one that is faster, cheaper to run at scale, and sharper on the only thing that matters.

### The technology we are building toward

Longer term, Intent Hybrid aims at a more advanced stack:

- **Forward simulation** :: not just detecting resonance, but simulating how a forming cascade would unfold (if these positions exit, who is liquidated next) to produce a probability and a countdown.
- **Edge inference** :: running detection close to the data, co-located with the sequencer and inside a trusted execution environment, for sub-100ms warnings.
- **Verifiable AI** :: cryptographic attestations (moving toward zk-ML) so the agent's signals and protective actions can be checked, not merely trusted.
- **Cross-domain resonance** :: reaching beyond a single venue to map correlated risk across markets and chains, catching herding wherever it forms.
- **A network of guardians** :: agents that coordinate their defense, so protection compounds as more of the ecosystem comes online.

These are ambitions, not shipped features. They define the direction we are building toward.

## Repository structure

```text
.
├── README.md
├── LICENSE
├── CONTRIBUTING.md
├── SECURITY.md
├── CHANGELOG.md
├── app/
│   ├── website.html        # marketing site (single-file SPA)
│   └── dapp.html           # Guardian dApp (single-file SPA)
├── scripts/
│   └── preconfirmation-listener.js   # example realtime ingestion listener
└── docs/
    ├── ARCHITECTURE.md     # the six-layer pipeline
    ├── RESONANCE.md        # how the Resonance Index works
    ├── API.md              # Resonance Index API overview
    └── ROADMAP.md          # phased roadmap
```

## Documentation

- [Architecture](docs/ARCHITECTURE.md) :: the six-layer pipeline.
- [Resonance Index](docs/RESONANCE.md) :: the crowding methodology.
- [API](docs/API.md) :: the real-time feed.
- [Roadmap](docs/ROADMAP.md) :: where this is going.
- [Security](SECURITY.md) :: custody model and disclosure.

## Getting started

This repository ships a self-contained website and dApp prototype.

```bash
# clone
git clone https://github.com/<your-handle>/intenthybrid.git
cd intenthybrid

# serve locally with any static server
npx serve .
# or
python3 -m http.server 8000
```

Then open `app/website.html` or `app/dapp.html` in your browser.

### Enabling real login (optional)

Wallet connect works out of the box through `window.ethereum`. Google, X, and email login use Supabase:

1. Create a free project at supabase.com and copy your **Project URL** and **anon key**.
2. Paste them into the `SUPABASE_URL` and `SUPABASE_ANON_KEY` constants near the top of the dApp script.
3. In Supabase, open **Authentication > Providers** and enable **Google** and **Twitter (X)**.
4. Set your deployed URL as the **Site URL** and add it to the **Redirect URLs** list.
5. Deploy (for example to Netlify) and open the app from the real URL. OAuth requires HTTPS, so it will not run from a local file.

## Roadmap

- **Phase 1 (2026 H1)** :: Resonance Index and Guardian read-only alerts.
- **Phase 2** :: Active Protection with scoped session keys.
- **Phase 3** :: multi-venue coverage and a public API.
- **Phase 4** :: an agent marketplace and custom guardians.
- **Phase 5 (2028+)** :: cross-domain resonance research.

## Disclaimer

Intent Hybrid is an early-stage research prototype. Figures and market data shown in the demo are simulated for illustration. Nothing here is financial advice, and the read-only tooling does not take custody of funds or trade on its own.

## License

Released under the MIT License. © intenthybrid
